# Hướng Dẫn Sử Dụng NotebookLM MCP Server

> **Phiên bản:** 1.0 | **Ngày cập nhật:** 25/01/2026

## Mục Lục

1. [Giới Thiệu](#1-giới-thiệu)
2. [Danh Sách 32 Tools](#2-danh-sách-32-tools)
3. [Use Case 1: Nghiên Cứu Chủ Đề Mới](#3-use-case-1-nghiên-cứu-chủ-đề-mới)
4. [Use Case 2: Tạo Podcast Từ Tài Liệu](#4-use-case-2-tạo-podcast-từ-tài-liệu)
5. [Use Case 3: Học Tập Với Flashcards & Quiz](#5-use-case-3-học-tập-với-flashcards--quiz)
6. [Use Case 4: Tạo Báo Cáo Từ Nhiều Nguồn](#6-use-case-4-tạo-báo-cáo-từ-nhiều-nguồn)
7. [Use Case 5: Quản Lý Kiến Thức Cá Nhân](#7-use-case-5-quản-lý-kiến-thức-cá-nhân)
8. [Mẹo Sử Dụng Hiệu Quả](#8-mẹo-sử-dụng-hiệu-quả)

---

## 1. Giới Thiệu

### NotebookLM là gì?

NotebookLM là công cụ AI của Google giúp bạn:
- **Tổng hợp thông tin** từ nhiều nguồn (PDF, website, YouTube, Google Docs)
- **Trò chuyện với AI** về nội dung tài liệu
- **Tạo nội dung đa phương tiện** (podcast, video, slides, infographic)
- **Hỗ trợ học tập** với flashcards, quiz, sơ đồ tư duy

### MCP Server mang lại gì?

Thay vì thao tác thủ công trên giao diện web, bạn có thể **yêu cầu AI Agent** thực hiện mọi thứ bằng ngôn ngữ tự nhiên:

| Cách truyền thống | Với MCP Server |
|-------------------|----------------|
| Mở trình duyệt → Đăng nhập → Click tạo notebook... | "Tạo notebook về AI" |
| Copy URL → Paste → Đợi xử lý... | "Thêm link này vào notebook" |
| Click Audio Overview → Chọn format → Đợi... | "Tạo podcast từ notebook" |

---

## 2. Danh Sách 33 Tools

### 🔐 Xác Thực & Tài Khoản (3 tools)

| Tool | Mô tả | Khi nào dùng |
|------|-------|--------------|
| `account_info` | Xem tài khoản đang dùng | Kiểm tra email và profile đang kết nối |
| `refresh_auth` | Tải lại token xác thực | Khi gặp lỗi "authentication failed" |
| `save_auth_tokens` | Lưu cookies thủ công | Khi xác thực tự động thất bại |

### 📓 Quản Lý Notebook (7 tools)

| Tool | Mô tả | Ví dụ yêu cầu |
|------|-------|---------------|
| `notebook_list` | Liệt kê tất cả notebooks | "Liệt kê notebooks của tôi" |
| `notebook_create` | Tạo notebook mới | "Tạo notebook về Machine Learning" |
| `notebook_get` | Xem chi tiết notebook | "Xem notebook này có những nguồn nào" |
| `notebook_describe` | Tóm tắt nội dung notebook | "Tóm tắt notebook này cho tôi" |
| `notebook_rename` | Đổi tên notebook | "Đổi tên notebook thành 'Dự án AI'" |
| `notebook_delete` | Xóa notebook vĩnh viễn | "Xóa notebook này" (cần xác nhận) |
| `notebook_query` | Hỏi AI về nội dung | "Hỏi notebook: Xu hướng AI 2026?" |

### 📚 Quản Lý Nguồn (7 tools)

| Tool | Mô tả | Ví dụ yêu cầu |
|------|-------|---------------|
| `notebook_add_url` | Thêm URL/YouTube | "Thêm link https://... vào notebook" |
| `notebook_add_text` | Thêm văn bản | "Thêm đoạn text này vào notebook" |
| `notebook_add_drive` | Thêm Google Docs/Slides | "Thêm file Drive ID này" |
| `source_describe` | Tóm tắt 1 nguồn | "Tóm tắt nguồn đầu tiên" |
| `source_get_content` | Lấy nội dung thô | "Lấy text của nguồn thứ 2" |
| `source_list_drive` | Liệt kê nguồn Drive | "Xem nguồn nào cần cập nhật" |
| `source_sync_drive` | Đồng bộ nguồn Drive | "Cập nhật nguồn Drive" |
| `source_delete` | Xóa nguồn | "Xóa nguồn thứ 3" |

### 💬 Chat (1 tool)

| Tool | Mô tả | Ví dụ yêu cầu |
|------|-------|---------------|
| `chat_configure` | Cấu hình AI chat | "Đặt AI thành learning guide" |

### 🔍 Nghiên Cứu (3 tools)

| Tool | Mô tả | Ví dụ yêu cầu |
|------|-------|---------------|
| `research_start` | Bắt đầu nghiên cứu | "Nghiên cứu sâu về quantum computing" |
| `research_status` | Kiểm tra tiến độ | "Nghiên cứu xong chưa?" |
| `research_import` | Import nguồn tìm được | "Import tất cả nguồn vào notebook" |

### 🎨 Tạo Nội Dung Studio (12 tools)

| Tool | Mô tả | Ví dụ yêu cầu |
|------|-------|---------------|
| `audio_overview_create` | Tạo podcast | "Tạo podcast dạng deep dive" |
| `video_overview_create` | Tạo video | "Tạo video giải thích" |
| `infographic_create` | Tạo infographic | "Tạo infographic landscape" |
| `slide_deck_create` | Tạo slides | "Tạo bộ slides thuyết trình" |
| `report_create` | Tạo báo cáo | "Tạo báo cáo dạng Study Guide" |
| `mind_map_create` | Tạo sơ đồ tư duy | "Tạo mind map về nội dung" |
| `flashcards_create` | Tạo flashcards | "Tạo flashcards độ khó medium" |
| `quiz_create` | Tạo quiz | "Tạo quiz 5 câu" |
| `data_table_create` | Tạo bảng dữ liệu | "Tạo bảng so sánh các AI models" |
| `studio_status` | Kiểm tra trạng thái | "Podcast đã xong chưa?" |
| `studio_delete` | Xóa artifact | "Xóa podcast cũ" |

---

## 3. Use Case 1: Nghiên Cứu Chủ Đề Mới

### Tình huống
Bạn muốn nghiên cứu về "AI trong giáo dục 2026" và cần tổng hợp thông tin từ nhiều nguồn.

### Quy trình thực hiện

**Bước 1: Yêu cầu AI nghiên cứu**
```
Bạn: Hãy nghiên cứu sâu về "AI trong giáo dục 2026" cho tôi
```

**AI Agent sẽ gọi:**
```python
research_start(
    query="AI trong giáo dục 2026",
    mode="deep",  # Nghiên cứu sâu, 3-5 phút
    title="Nghiên cứu: AI trong giáo dục 2026"
)
```

**Kết quả trả về:**
```json
{
    "status": "success",
    "task_id": "abc123",
    "notebook_id": "xyz789",
    "message": "Deep Research started. This takes 3-5 minutes."
}
```

**Bước 2: Kiểm tra tiến độ**
```
Bạn: Nghiên cứu xong chưa?
```

**AI Agent gọi:**
```python
research_status(notebook_id="xyz789", max_wait=300)
```

**Kết quả:**
```json
{
    "status": "completed",
    "source_count": 42,
    "report": "## Tóm tắt nghiên cứu\n\nAI đang thay đổi giáo dục...",
    "sources": [
        {"title": "AI Education Trends 2026", "url": "..."},
        {"title": "Personalized Learning with AI", "url": "..."}
    ]
}
```

**Bước 3: Import nguồn**
```
Bạn: Import tất cả nguồn vào notebook
```

**AI Agent gọi:**
```python
research_import(notebook_id="xyz789", task_id="abc123")
```

**Bước 4: Hỏi về nội dung**
```
Bạn: Xu hướng chính của AI trong giáo dục là gì?
```

**AI Agent gọi:**
```python
notebook_query(
    notebook_id="xyz789",
    query="Xu hướng chính của AI trong giáo dục là gì?"
)
```

---

## 4. Use Case 2: Tạo Podcast Từ Tài Liệu

### Tình huống
Bạn có một notebook chứa nhiều tài liệu về "Startup Pitch Deck" và muốn tạo podcast để nghe khi chạy bộ.

### Quy trình thực hiện

**Bước 1: Yêu cầu tạo podcast**
```
Bạn: Tạo podcast dạng deep dive về startup pitch deck, ngôn ngữ tiếng Việt
```

**AI Agent sẽ hỏi xác nhận trước:**
```json
{
    "status": "pending_confirmation",
    "message": "Xác nhận cài đặt trước khi tạo:",
    "settings": {
        "format": "deep_dive",
        "length": "default",
        "language": "vi"
    }
}
```

**Bước 2: Xác nhận và tạo**
```
Bạn: Đồng ý, tạo đi
```

**AI Agent gọi với confirm=True:**
```python
audio_overview_create(
    notebook_id="...",
    format="deep_dive",
    language="vi",
    confirm=True
)
```

**Bước 3: Kiểm tra trạng thái**
```
Bạn: Podcast xong chưa?
```

**AI Agent gọi:**
```python
studio_status(notebook_id="...")
```

**Kết quả khi hoàn thành:**
```json
{
    "status": "success",
    "artifacts": [
        {
            "type": "audio",
            "status": "completed",
            "url": "https://..."
        }
    ]
}
```

### Các định dạng podcast có sẵn

| Format | Mô tả | Thời lượng |
|--------|-------|------------|
| `deep_dive` | 2 người dẫn thảo luận sâu | 15-30 phút |
| `brief` | Tóm tắt ngắn gọn | 5-10 phút |
| `critique` | Phân tích phản biện | 15-20 phút |
| `debate` | Tranh luận 2 phía | 20-30 phút |

---

## 5. Use Case 3: Học Tập Với Flashcards & Quiz

### Tình huống
Bạn đang chuẩn bị cho kỳ thi và muốn ôn tập hiệu quả với flashcards và quiz.

### Quy trình thực hiện

**Bước 1: Tạo flashcards**
```
Bạn: Tạo flashcards từ notebook này, độ khó medium
```

**AI Agent gọi:**
```python
flashcards_create(
    notebook_id="...",
    difficulty="medium",
    confirm=True
)
```

**Bước 2: Tạo quiz**
```
Bạn: Tạo quiz 10 câu hỏi trắc nghiệm
```

**AI Agent gọi:**
```python
quiz_create(
    notebook_id="...",
    question_count=10,
    difficulty="medium",
    confirm=True
)
```

**Bước 3: Tạo sơ đồ tư duy để nhớ tổng quan**
```
Bạn: Tạo mind map để tôi nắm được bố cục
```

**AI Agent gọi:**
```python
mind_map_create(
    notebook_id="...",
    title="Tổng quan chủ đề",
    confirm=True
)
```

---

## 6. Use Case 4: Tạo Báo Cáo Từ Nhiều Nguồn

### Tình huống
Bạn cần tổng hợp nhiều nguồn khác nhau thành một báo cáo dạng "Briefing Doc".

### Quy trình thực hiện

**Bước 1: Thêm nguồn**
```
Bạn: 
- Thêm URL https://example.com/ai-report-2026
- Thêm video YouTube https://youtube.com/watch?v=...
- Thêm đoạn text tôi paste ở đây: "..."
```

**AI Agent gọi lần lượt:**
```python
notebook_add_url(notebook_id="...", url="https://example.com/ai-report-2026")
notebook_add_url(notebook_id="...", url="https://youtube.com/watch?v=...")
notebook_add_text(notebook_id="...", text="...", title="Ghi chú của tôi")
```

**Bước 2: Tạo báo cáo**
```
Bạn: Tạo báo cáo dạng Briefing Doc từ tất cả nguồn
```

**AI Agent gọi:**
```python
report_create(
    notebook_id="...",
    report_format="Briefing Doc",
    language="vi",
    confirm=True
)
```

### Các định dạng báo cáo

| Format | Mô tả | Phù hợp cho |
|--------|-------|-------------|
| `Briefing Doc` | Tóm tắt điểm chính | Họp, báo cáo nhanh |
| `Study Guide` | Hướng dẫn học tập | Ôn tập, học sinh |
| `Blog Post` | Bài viết blog | Nội dung chia sẻ |
| `Create Your Own` | Tùy chỉnh prompt | Yêu cầu đặc biệt |

---

## 7. Use Case 5: Quản Lý Kiến Thức Cá Nhân

### Tình huống
Bạn đọc nhiều tài liệu hàng ngày và muốn lưu trữ, tổ chức kiến thức.

### Quy trình thực hiện

**Bước 1: Tạo notebook theo chủ đề**
```
Bạn: Tạo notebook mới tên "Kiến thức AI 2026"
```

**Bước 2: Thêm nguồn hàng ngày**
```
Bạn: Thêm link này vào notebook Kiến thức AI: https://...
```

**Bước 3: Định kỳ hỏi tóm tắt**
```
Bạn: Tóm tắt những điểm quan trọng nhất từ tất cả nguồn trong notebook
```

**Bước 4: Tạo infographic để chia sẻ**
```
Bạn: Tạo infographic tổng hợp kiến thức, định hướng landscape
```

---

## 8. Mẹo Sử Dụng Hiệu Quả

### ✅ Nên làm

1. **Đặt tên notebook rõ ràng**
   - ✅ "Nghiên cứu AI Giáo dục Q1-2026"
   - ❌ "Untitled Notebook"

2. **Sử dụng research mode phù hợp**
   - `fast`: Khi cần nhanh (30s, ~10 nguồn)
   - `deep`: Khi cần chi tiết (5 phút, ~40 nguồn)

3. **Xác nhận trước khi tạo nội dung**
   - Studio content (podcast, video...) tốn thời gian tạo
   - Kiểm tra cài đặt trước khi confirm

4. **Kiểm tra trạng thái định kỳ**
   - Dùng `studio_status` để xem tiến độ
   - Deep research có thể mất 3-5 phút

### ❌ Không nên

1. **Không xóa notebook/nguồn vội vàng**
   - Hành động không thể hoàn tác
   - Luôn yêu cầu xác nhận

2. **Không thêm quá nhiều nguồn cùng lúc**
   - Mỗi lần thêm 1 nguồn
   - Đợi xử lý xong mới thêm tiếp

3. **Không dùng research_start cho câu hỏi đơn giản**
   - Câu hỏi về nguồn có sẵn: dùng `notebook_query`
   - Tìm nguồn mới: dùng `research_start`

---

*Tài liệu được tạo tự động bởi AI Agent. Cập nhật lần cuối: 26/01/2026*
