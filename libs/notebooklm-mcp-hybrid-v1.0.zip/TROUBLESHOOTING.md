# NotebookLM MCP - Kinh Nghiệm Triển Khai & Troubleshooting

> Tài liệu này ghi lại các vấn đề đã gặp, nguyên nhân, và giải pháp trong quá trình triển khai NotebookLM MCP Server với Antigravity.

---

## 🔐 1. Lỗi Xác Thực (Authentication)

### 1.1 Thử nghiệm đọc trực tiếp từ Chrome Database (❌ THẤT BẠI)

**Mục tiêu:** Đọc cookies từ file SQLite của Chrome (`%LOCALAPPDATA%\Google\Chrome\User Data\Default\Network\Cookies`)

**Các phương pháp đã thử:**
1. **DPAPI Decryption** - Giải mã bằng Windows DPAPI
2. **AES-GCM với key từ Local State** - Đọc encrypted_key từ Chrome Local State

**Kết quả:** Thất bại hoàn toàn

**Nguyên nhân:**
- Chrome v127+ sử dụng **App-Bound Encryption** (v20 encryption)
- Key được bảo vệ bởi Windows Security, chỉ Chrome process mới có thể access
- Không thể bypass bằng DPAPI hoặc đọc từ Local State

**Kết luận:** Việc sử dụng script bên thứ ba để đọc database cá nhân của trình duyệt tiềm ẩn rủi ro nếu không được kiểm soát chặt chẽ.

---

### 1.2 Giải pháp 1: Chrome DevTools Protocol (✅ THÀNH CÔNG)

**Phương pháp:** Sử dụng CDP để lấy cookies từ Chrome đang chạy

```powershell
notebooklm-mcp-auth
```

**Cách hoạt động:**
1. Mở Chrome với `--remote-debugging-port=9222`
2. Kết nối WebSocket tới Chrome debugger
3. Gọi `Network.getAllCookies` để lấy tất cả cookies (bao gồm HttpOnly)
4. Trích xuất CSRF token từ page bằng JavaScript evaluation

**Ưu điểm:**
- Lấy được đầy đủ 23-27 cookies
- Bao gồm HttpOnly cookies (`__Secure-*`)
- Không cần crack encryption

---

### 1.3 Giải pháp 2 (KHUYẾN NGHỊ): Chế độ File (Import Cookies)

Dùng khi trình duyệt tự động gặp lỗi hoặc bạn muốn dùng chính phiên bản Chrome đang mở:

1. Chạy lệnh: `notebooklm-mcp-auth --file`
2. Mở Chrome bình thường, F12 -> Network tab -> filter `batchexecute`.
3. Copy toàn bộ giá trị trong header `cookie` của một request.
4. Paste vào terminal hoặc file theo yêu cầu của script.

**Lưu ý quan trọng về Bảo mật**:
- Các cookie quan trọng như `HSID`, `SSID`, `__Secure-3PSID` thường có thuộc tính **HttpOnly**, nghĩa là script (JavaScript) hoặc AI Agent không thể truy cập trực tiếp.
- Do đó, việc copy thủ công từ **Network tab** (Request Headers) là cách duy nhất để lấy đầy đủ token xác thực nếu không sử dụng trình duyệt remote debugging do chính script (`notebooklm-mcp-auth`) khởi tạo.

---

### 1.4 Tại sao AI Agent không thể tự động lấy cookies?

Trong quá trình phát triển, chúng tôi đã thử sử dụng AI (Browser Subagent) để tự động hóa việc này nhưng gặp các rào cản kỹ thuật sau:

1. **Cơ chế HttpOnly**: Trình duyệt chặn mọi nỗ lực truy cập cookie bảo mật qua JavaScript (kể cả từ console).
2. **DevTools isolation**: Bảng điều khiển DevTools (F12) nằm ngoài phạm vi tiếp cận của DOM. AI Agent không thể click chuột hay copy text từ panel Network một cách tin cậy.
3. **Cookies thiếu hụt = Auth Fail**: Việc chỉ lấy được 7-9 cookies công khai (non-HttpOnly) là không đủ.

**Lời khuyên**: Hãy kiên nhẫn thực hiện **Giải pháp 2** (Copy manual từ Network tab). Đây là cách an toàn và đảm bảo lấy được 100% token cần thiết.

---

## 📦 2. Lỗi Module (Module Not Found)

### Triệu chứng:
Lỗi `ModuleNotFoundError: No module named 'notebooklm_mcp_hybrid'` hoặc `No module named 'fastmcp'`.

### Giải pháp:
1. **Cài đặt lại package**:
   ```powershell
   cd "path/to/notebooklm-mcp-hybrid"
   pip install -e .
   ```
2. **Cài đặt thủ công dependency**:
   ```powershell
   pip install fastmcp
   ```
3. **Kiểm tra Python**: Đảm bảo bạn đang dùng đúng phiên bản Python đã khai báo trong `mcp_config.json`.

---

## 🌐 3. Lỗi Chrome Khởi Chạy (Chrome Debugger)

### Triệu chứng:
Script `notebooklm-mcp-auth` không mở được Chrome hoặc báo lỗi không thể kết nối debugger (port 9222).

### Giải pháp:
1. Đảm bảo Google Chrome đã được cài đặt tại đường dẫn mặc định.
2. **Lỗi WinError 10061**: Thường do debugger port (9222) chưa sẵn sàng hoặc bị firewall chặn. Thử tắt Chrome chính và chạy lại script.
3. **Bận Port**: Đảm bảo không có instance Chrome debugger nào khác đang chạy trên port 9222.
4. **Dùng File Mode**: Nếu lỗi debugger quá phức tạp, hãy sử dụng `notebooklm-mcp-auth --file` (xem mục 1.3).

---

## 🆘 4. Lỗi Tên Biến/Module (NameError) Sau Nâng Cấp

### Triệu chứng:
Chạy `notebooklm-mcp-auth` báo lỗi `NameError: name 'os' is not defined`.

### Nguyên nhân:
Trong quá trình nâng cấp hỗ trợ đa tài khoản (Multi-account), module `os` có thể chưa được import trong file `auth_cli.py`.

### Giải pháp:
Lỗi này đã được **vá hoàn toàn** trong codebase. Nếu bạn vẫn gặp lỗi này, hãy đảm bảo bạn đã pull phiên bản mới nhất hoặc cài đặt lại project bằng `pip install -e .`.

---

## 📧 5. Email Tài Khoản Hiển Thị "(không xác định)"

### Triệu chứng:
Gọi tool `account_info` trả về email là `(không xác định - token cũ)`.

### Giải pháp:
Đây là hiện tượng bình thường đối với các tokens được tạo trước phiên bản hỗ trợ đa tài khoản. Để hiển thị email:
1. Xóa file `auth.json` cũ (thường ở `~/.notebooklm-mcp/auth.json`).
2. Chạy lại `notebooklm-mcp-auth`.
3. Đăng nhập thành công, hệ thống sẽ tự động trích xuất và lưu email vào token mới.

---

## 👤 6. Multi-Account Support

### 6.1 Thiết kế Architecture

**Yêu cầu:** Hỗ trợ nhiều tài khoản Google NotebookLM đồng thời

**Giải pháp đã triển khai:**

| Component | Thay đổi |
|-----------|----------|
| `auth.py` | Thêm field `email` vào AuthTokens, hỗ trợ `NOTEBOOKLM_AUTH_DIR` env var |
| `auth_cli.py` | Thêm `--profile <name>` option, extract email từ page |
| `server.py` | Thêm tool `account_info` để xem tài khoản đang dùng |

**Cấu trúc thư mục profile:**
```
~/.notebooklm-mcp-<profile_name>/
├── auth.json          # Cookies, CSRF token, email
└── chrome-profile/    # Chrome user data (persistent login)
```

### 6.2 Trích xuất Email từ Page

**Phương pháp:** Chạy JavaScript trên NotebookLM page qua CDP

**Các vị trí tìm email:**
1. Google's `ub` object: `ub && ub.he && ub.he.Aa`
2. HTML attribute: `[data-email]`
3. Email pattern trong HTML content

---

## ⚙️ 7. Lỗi Tên Công Cụ Không Xác Định (Unknown Tool Name)

### Triệu chứng:
Gọi công cụ trên server phụ (ví dụ: `mcp_notebooklm_second_notebook_list`) báo lỗi `unknown tool name`.

### Nguyên nhân:
1. **Antigravity chưa restart**: Các server mới thêm vào `mcp_config.json` chỉ được load sau khi khởi động lại ứng dụng chủ.
2. **Đặt tên Server không hợp lệ**: Tên server quá dài hoặc chứa nhiều ký tự đặc biệt có thể khiến việc đăng ký tool thất bại.
3. **Giới hạn Server Đồng Thời**: Antigravity có giới hạn ngầm về số lượng instance. Thực nghiệm cho thấy chạy **2 servers** là ngưỡng ổn định nhất.

### Giải pháp:
1. **Restart Antigravity/Cursor/VS Code**.
2. **Đơn giản hóa tên server**: Đổi tên server thành các từ ngắn gọn, không dùng dấu chấm hoặc @.
3. **Dùng format CamelCase**: `notebooklmSub` thay vì `notebooklm_sub`.
4. **Kiểm tra auth.json**: Đảm bảo file `auth.json` tồn tại trong thư mục được chỉ định bởi `NOTEBOOKLM_AUTH_DIR`.

---

## 🔧 8. Cấu Hình MCP Servers

### 8.1 Giới hạn số lượng servers (⚠️ LIMITATION)

**Phát hiện:** Antigravity chỉ load được **tối đa 2 MCP servers** hoạt động đồng thời

**Triệu chứng:**
- Server được nhận diện (`list_resources` không lỗi)
- Nhưng tools không được đăng ký (`unknown tool name`)
- Luân phiên: lúc server A hoạt động, lúc server B hoạt động

**Giải pháp:** Chỉ cấu hình 2 servers cùng lúc, disable server không dùng thường xuyên

### 8.2 Quy tắc đặt tên server

| Format | Ví dụ | Kết quả |
|--------|-------|---------|
| underscore | `notebooklm_second` | ❌ Không ổn định |
| camelCase | `notebooklmSub` | ✅ Hoạt động |
| hyphen | `notebooklm-second` | Chưa test |

**Khuyến nghị:** Dùng camelCase cho tên server phụ

### 8.3 Template cấu hình 2 servers

```json
{
  "mcpServers": {
    "notebooklm": {
      "command": "python.exe",
      "args": ["-m", "notebooklm_mcp_hybrid.server"],
      "cwd": "<path_to_src>",
      "env": {
        "NOTEBOOKLM_AUTH_DIR": "~/.notebooklm-mcp-main"
      }
    },
    "notebooklmSub": {
      "command": "python.exe", 
      "args": ["-m", "notebooklm_mcp_hybrid.server"],
      "cwd": "<path_to_src>",
      "env": {
        "NOTEBOOKLM_AUTH_DIR": "~/.notebooklm-mcp-sub"
      }
    }
  }
}
```

### 8.4 Thêm tài khoản mới

```powershell
# 1. Tạo profile mới
notebooklm-mcp-auth --profile <new_profile_name>

# 2. Đăng nhập trong Chrome popup

# 3. Thêm server vào mcp_config.json

# 4. Restart Antigravity
```

---

## 🧭 9. Server Vẫn Load Tài Khoản Cũ Sau Khi Hard Reset

### Triệu chứng:
Bạn đã gọi `Hard Reset` (xóa folder profile), đã xác thực tài khoản mới qua CLI, nhưng khi gọi `account_info` hoặc `notebook_list` trong AI Agent, nó vẫn báo email cũ hoặc báo lỗi không tìm thấy token.

### Nguyên nhân:
**Lỗi Mismatch cấu hình**: Host application (Cursor/Antigravity) vẫn đang truyền biến môi trường `NOTEBOOKLM_AUTH_DIR` trỏ về thư mục cũ.

### Giải pháp:
1. **Kiểm tra Cấu hình**: Mở file `mcp_config.json` của Antigravity (thường tại `%USERPROFILE%\.gemini\antigravity\mcp_config.json`).
2. **Đồng bộ đường dẫn**: Đảm bảo giá trị của `NOTEBOOKLM_AUTH_DIR` trong file json này khớp chính xác với thư mục profile bạn vừa tạo qua CLI.
3. **Restart Host**: Bạn **bắt buộc** phải Restart hoàn toàn ứng dụng để cập nhật biến môi trường mới cho server instance.
4. **Tuyệt đối tránh**: Không sử dụng đường dẫn tương đối (`~`) nếu host application không hỗ trợ resolve home directory (Antigravity ưu tiên đường dẫn tuyệt đối).

---

## 👻 10. "Ghost Tools" - Công Cụ Vẫn Hiển Thị Dù Đã Xóa Server

### Triệu chứng:
Bạn đã xóa hoặc đổi tên một server trong `mcp_config.json`, nhưng AI Agent vẫn cố gắng gọi tên cũ hoặc bạn vẫn thấy tên cũ trong danh sách công cụ.

### Nguyên nhân:
**Cơ chế Tool Registration Persistence**:
1. **Cache của Host**: Một số host MCP (như Antigravity) có thể lưu lại danh sách công cụ đã đăng ký trong phiên làm việc hiện tại.
2. **Agent Memory**: AI Agent có thể ghi nhớ tên công cụ từ các lượt hội thoại trước (context).

### Giải pháp:
1. **Force Restart**: Thoát hoàn toàn ứng dụng Antigravity và khởi động lại.
2. **Đổi sang tên hoàn toàn mới**: Thay vì sửa server cũ, hãy đổi hẳn sang một cái tên mới chưa từng dùng (ví dụ: `notebooklmSub` thay vì `notebooklmSecond`). Việc này buộc Host phải đăng ký lại một bộ toolset mới.
3. **Clear conversation context**: Bắt đầu một phiên hội thoại mới để xóa bỏ "ký ức" của Agent.

---

## 🔄 11. Case Study: Profile Mismatch Khi Switch Account

### Bối cảnh:
Chuyển từ tài khoản `account-a@gmail.com` sang `account-b@gmail.com` cho một server.

### Triệu chứng:
- Đã xóa auth cache cũ, chạy xác thực mới thành công
- `account_info` báo email mới đúng
- **Nhưng** `notebook_list` vẫn trả về notebooks của tài khoản cũ!

### Nguyên nhân gốc:
**Config Mismatch & Tool Registration Cache**: File `mcp_config.json` có server tên khác với tên đang được Agent gọi từ cache/context cũ (Ghost Tools).

### Quy trình xử lý:

```powershell
# 1. Xác định cấu hình thực tế
Get-Content "$env:USERPROFILE\.gemini\antigravity\mcp_config.json"

# 2. Liệt kê profile tồn tại
Get-ChildItem "$env:USERPROFILE" -Directory -Filter ".notebooklm-mcp-*"

# 3. Xóa profile cũ (Hard Reset)
Remove-Item "$env:USERPROFILE\.notebooklm-mcp-<old>" -Recurse -Force

# 4. Đồng bộ và Chuẩn hóa tên server
# Đổi sang một cái tên HOÀN TOÀN MỚI (ví dụ: 'notebooklmSub')
# để buộc Host phải đăng ký lại toolset

# 5. RESTART Antigravity (bắt buộc!)
```

### Best Practice - Tên Server chuẩn:

| Server | Tên chuẩn | Auth Directory |
|--------|-----------|----------------|
| Chính | `notebooklm` | `~/.notebooklm-mcp-main` |
| Phụ | `notebooklmSub` | `~/.notebooklm-mcp-sub` |

**Lưu ý**: Tên ngắn gọn, camelCase, không chứa `.` hoặc `@`.

---

## ✅ 12. Troubleshooting Checklist

### Authentication không thành công

- [ ] Chrome đã được đóng hoàn toàn trước khi chạy auth?
- [ ] Port 9222 có bị chiếm không? (`netstat -an | findstr 9222`)
- [ ] Đã đăng nhập Google trong Chrome popup chưa?
- [ ] NotebookLM page có load được không?

### Server không hoạt động

- [ ] `NOTEBOOKLM_AUTH_DIR` trỏ đúng thư mục chứa `auth.json`?
- [ ] File `auth.json` có tồn tại và valid JSON?
- [ ] Đã restart Antigravity sau khi sửa config?
- [ ] Chỉ có tối đa 2 NotebookLM servers active?

### Tool không được nhận diện

- [ ] Thử `list_resources` để xem server có được load?
- [ ] Đổi tên server sang camelCase?
- [ ] Disable các servers khác, chỉ giữ 2?

---

## 📁 13. Files Quan Trọng

| File | Mô tả |
|------|-------|
| `src/notebooklm_mcp_hybrid/auth.py` | AuthTokens class, get_cache_path() |
| `src/notebooklm_mcp_hybrid/auth_cli.py` | CLI tool xác thực, CDP connection |
| `src/notebooklm_mcp_hybrid/server.py` | MCP server, account_info tool |
| `~/.notebooklm-mcp-<profile>/auth.json` | Cached auth tokens |
| `mcp_config.json` | Antigravity MCP server configuration |

---

## 📦 14. Bảo Trì & Phân Phối

### Đồng bộ tài liệu:
Khi có những thay đổi quan trọng trong `Troubleshooting`, cần đảm bảo các file sau được cập nhật đồng bộ:
1. **Knowledge Item**: Tại `~/.gemini/antigravity/knowledge/notebooklm_mcp_server/`.
2. **Project Root**: File `TROUBLESHOOTING.md`, `README.md` trong thư mục gốc của project.

### Tạo gói phân phối (Zip):
Sau khi cập nhật tài liệu và code, hãy tạo lại file zip phân phối:
```powershell
Compress-Archive -Path "path/to/project/*" -DestinationPath "notebooklm-mcp-hybrid-v1.x.zip" -Force
```

---

## 📝 Changelog

### 2026-01-27
- ✅ Triển khai Multi-Account Support
- ✅ Thêm `--profile` CLI option
- ✅ Thêm `account_info` MCP tool
- ✅ Fix Chrome cookie extraction với CDP
- ✅ Thêm Case Study: Profile Mismatch khi Switch Account
- ✅ Thêm các case troubleshooting: NameError, Ghost Tools, Config Mismatch
- ⚠️ Phát hiện giới hạn 2 servers đồng thời
