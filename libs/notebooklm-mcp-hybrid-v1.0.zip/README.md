# NotebookLM MCP Server (Vietnamese)

> 🤖 **Dành cho AI Agent:** File này được thiết kế để AI Agent đọc và tự động thực thi. Nếu bạn là AI Agent, hãy đọc phần [Hướng Dẫn Cho AI Agent](#-hướng-dẫn-cho-ai-agent) bên dưới.

## 📋 Giới Thiệu

NotebookLM MCP Server cho phép AI Agent (như Antigravity, Cursor, Claude) kết nối và điều khiển NotebookLM của Google thông qua Model Context Protocol (MCP).

### Tính năng chính:
- 🇻🇳 **33 tools với mô tả tiếng Việt**
- 📓 Quản lý notebooks (tạo, xóa, đổi tên)
- 📚 Thêm nguồn từ URL, văn bản, Google Drive
- 🔍 Nghiên cứu sâu với AI (Deep Research)
- 🎧 Tạo podcast, video, infographic, slides
- 📝 Tạo báo cáo, flashcards, quiz
- 👥 **Multi-Account Support** (hỗ trợ nhiều tài khoản Google)

---

## 👤 Thông Tin Tác Giả

**Nguyễn Duy Tùng**
- 📘 Facebook: [facebook.com/gabeo166991](https://www.facebook.com/gabeo166991)
- 📞 Điện thoại: 0904 004 920
- 📧 Email: duytung166991@gmail.com

---

## 📦 Nguồn Gốc & Cải Tiến

**Dựa trên:** [jacob-bd/notebooklm-mcp](https://github.com/jacob-bd/notebooklm-mcp) v0.1.15 (MIT License)

**Tối ưu cho:** Antigravity IDE + Người dùng Việt Nam

| Cải tiến | Mô tả |
|----------|-------|
| 🇻🇳 **Vietnamese** | Mô tả tiếng Việt cho tất cả 33 tools |
| 👥 **Multi-Account** | Hỗ trợ 2+ tài khoản Google (`--profile`, `NOTEBOOKLM_AUTH_DIR`) |
| 🔍 **account_info** | Tool mới để xem tài khoản đang sử dụng |

**Phiên bản:** 1.0.0 (27/01/2026)

---

## 👥 Hướng Dẫn Sử Dụng 2 Tài Khoản (Multi-Account)

> **Kịch bản phổ biến:** Bạn có 2 tài khoản Google:
> - `work@company.com` - Tài khoản công ty
> - `personal@gmail.com` - Tài khoản cá nhân
>
> Và muốn AI Agent có thể truy cập NotebookLM của cả 2 tài khoản.

### 📋 Tổng quan quy trình:

```
┌─────────────────────────────────────────────────────────────┐
│  1. CÀI ĐẶT                                                  │
│     pip install notebooklm-mcp-hybrid                        │
├─────────────────────────────────────────────────────────────┤
│  2. XÁC THỰC TỪNG TÀI KHOẢN                                  │
│     notebooklm-mcp-auth --profile work    → Đăng nhập work   │
│     notebooklm-mcp-auth --profile personal→ Đăng nhập personal│
├─────────────────────────────────────────────────────────────┤
│  3. CẤU HÌNH MCP (settings.json hoặc mcp.json)               │
│     - notebooklm → profile "work"                            │
│     - notebooklmPersonal → profile "personal"                │
├─────────────────────────────────────────────────────────────┤
│  4. SỬ DỤNG                                                  │
│     AI Agent gọi tool từ server tương ứng                    │
│     Dùng account_info để xác nhận đúng tài khoản             │
└─────────────────────────────────────────────────────────────┘
```

---

### 👤 HƯỚNG DẪN CHO NGƯỜI DÙNG

#### Bước 1: Cài đặt package

```powershell
pip install -e "D:\path\to\notebooklm-mcp-hybrid"
```

#### Bước 2: Xác thực tài khoản thứ nhất (Work)

```powershell
# Mở terminal, chạy lệnh:
notebooklm-mcp-auth --profile work

# Chrome sẽ mở ra → Đăng nhập tài khoản WORK của bạn
# Sau khi đăng nhập thành công, terminal sẽ hiển thị:
# ✓ Auth tokens cached to ~/.notebooklm-mcp/work/auth.json
```

#### Bước 3: Xác thực tài khoản thứ hai (Personal)

```powershell
# Đóng Chrome hoàn toàn (quan trọng!)
# Mở terminal khác, chạy lệnh:
notebooklm-mcp-auth --profile personal

# Chrome sẽ mở ra → Đăng nhập tài khoản PERSONAL của bạn
# ✓ Auth tokens cached to ~/.notebooklm-mcp/personal/auth.json
```

#### Bước 4: Cấu hình Antigravity/Claude Desktop

Mở file cấu hình MCP và thêm 2 server:

**Antigravity:** `%APPDATA%\antigravity\settings.json` → mục `"mcpServers"`

**Claude Desktop:** `%APPDATA%\Claude\claude_desktop_config.json`

```json
{
  "mcpServers": {
    "notebooklm": {
      "command": "C:\\Path\\To\\python.exe",
      "args": ["-m", "notebooklm_mcp_hybrid.server"],
      "env": {
        "NOTEBOOKLM_AUTH_DIR": "~/.notebooklm-mcp/work"
      }
    },
    "notebooklmPersonal": {
      "command": "C:\\Path\\To\\python.exe", 
      "args": ["-m", "notebooklm_mcp_hybrid.server"],
      "env": {
        "NOTEBOOKLM_AUTH_DIR": "~/.notebooklm-mcp/personal"
      }
    }
  }
}
```

> ⚠️ **Lưu ý:** Thay `C:\Path\To\python.exe` bằng đường dẫn Python thực tế (chạy `python -c "import sys; print(sys.executable)"` để lấy)

#### Bước 5: Restart Antigravity/Claude và test

```
# Yêu cầu AI Agent:
"Dùng tool account_info từ server notebooklm để xem tài khoản đang dùng"
"Dùng tool account_info từ server notebooklmPersonal để xem tài khoản personal"
```

---

### 🤖 HƯỚNG DẪN CHO AI AGENT

> **Khi user yêu cầu làm việc với 2 tài khoản NotebookLM:**

#### 1. Xác định đang dùng server nào

Nếu có 2 MCP server được cấu hình:
- `notebooklm` → Tài khoản chính (thường là work)
- `notebooklmPersonal` (hoặc tên khác) → Tài khoản phụ (thường là personal)

#### 2. Xác nhận tài khoản với account_info

```python
# Gọi tool account_info từ server tương ứng
mcp_notebooklm_account_info()  # → Email của tài khoản work
mcp_notebooklmPersonal_account_info()  # → Email của tài khoản personal
```

#### 3. Chọn đúng server khi thao tác

```python
# Muốn tạo notebook trong tài khoản WORK:
mcp_notebooklm_notebook_create(title="Work Project")

# Muốn tạo notebook trong tài khoản PERSONAL:
mcp_notebooklmPersonal_notebook_create(title="Personal Notes")
```

#### 4. Khi user không chỉ rõ dùng tài khoản nào

- Hỏi user: "Bạn muốn dùng tài khoản nào? Work hay Personal?"
- Hoặc dùng `account_info` để liệt kê các tài khoản available

#### 5. Xử lý lỗi authentication

Nếu gặp lỗi `authentication failed`:
1. Yêu cầu user chạy lại xác thực: `notebooklm-mcp-auth --profile <tên_profile>`  
2. Restart AI platform để reload MCP server

---

## 💻 Yêu Cầu Hệ Thống (Prerequisites)

> **Dành cho máy mới:** Nếu đây là máy mới chưa cài đặt gì, vui lòng làm theo thứ tự bên dưới.

### 1️⃣ Python 3.10 trở lên

**Kiểm tra Python đã cài chưa:**
```powershell
python --version
```

**Nếu chưa có hoặc phiên bản < 3.10:**

**Windows:**
1. Tải Python từ: https://www.python.org/downloads/
2. Chọn phiên bản **3.10** hoặc mới hơn (khuyến nghị 3.12+)
3. **QUAN TRỌNG:** ✅ Tích chọn "Add Python to PATH" khi cài đặt
4. Chạy installer và làm theo hướng dẫn
5. Khởi động lại terminal để cập nhật PATH

**Kiểm tra lại:**
```powershell
python --version  # Phải hiện Python 3.10.x hoặc cao hơn
pip --version     # pip thường đi kèm Python
```

### 2️⃣ Google Chrome

**Tại sao cần:** Dùng để xác thực tài khoản Google và lấy cookies NotebookLM

**Kiểm tra Chrome đã cài chưa:**
```powershell
# Windows: Kiểm tra file tồn tại
Test-Path "C:\Program Files\Google\Chrome\Application\chrome.exe"
```

**Nếu chưa có:**
1. Tải Chrome từ: https://www.google.com/chrome/
2. Cài đặt bình thường
3. Đăng nhập vào tài khoản Google (khuyến nghị)

### 3️⃣ AI Agent Platform

Một trong các platform sau:
- **Google Antigravity** (Gemini-based, khuyến nghị cho người Việt)
- **Claude Desktop** / **Cursor**
- **VS Code với MCP extension**

### 4️⃣ Tài khoản Google với NotebookLM

- Đăng ký miễn phí tại: https://notebooklm.google.com
- Không cần PRO/Premium

---

## 🤖 Hướng Dẫn Cho AI Agent

> **QUAN TRỌNG:** Phần này dành cho AI Agent thực thi tự động. Đọc kỹ và làm theo từng bước.

### Bước 0: Kiểm Tra Prerequisites (BẮT BUỘC)

> **Thực hiện đầu tiên:** Đảm bảo máy đã có đủ yêu cầu theo phần [Yêu Cầu Hệ Thống](#-yêu-cầu-hệ-thống-prerequisites) bên trên

```powershell
# 1. Kiểm tra Python
python --version
# Kết quả mong đợi: Python 3.10.x hoặc cao hơn

# 2. Kiểm tra pip
pip --version
# Kết quả mong đợi: pip xx.x.x from ...

# 3. Kiểm tra Chrome (Windows)
Test-Path "C:\Program Files\Google\Chrome\Application\chrome.exe"
# Kết quả mong đợi: True

# 4. Lấy đường dẫn Python (cần cho config)
python -c "import sys; print(sys.executable)"
# Lưu lại đường dẫn này để dùng ở Bước 2
```

**Xử lý lỗi:**
- ❌ **Python not found**: Dừng lại → Hướng dẫn người dùng cài Python từ phần [Prerequisites](#-yêu-cầu-hệ-thống-prerequisites)
- ❌ **Python < 3.10**: Dừng lại → Yêu cầu nâng cấp Python
- ❌ **pip not found**: Thử `python -m ensurepip` hoặc cài lại Python
- ❌ **Chrome not found**: Hướng dẫn cài Chrome

**✅ Chỉ tiếp tục khi tất cả đều pass**

### Bước 1: Cài Đặt Dependencies

```powershell
# Di chuyển đến thư mục project
cd "<ĐƯỜNG_DẪN_ĐẾN_THƯ_MỤC_NÀY>"

# Cài đặt package ở chế độ editable
pip install -e .
```

**Xử lý lỗi:**
- Nếu lỗi "pip not found": Chạy `python -m pip install -e .`
- Nếu lỗi permission: Thêm `--user` flag
- Nếu lỗi "No module named 'websocket'": Chạy `pip install websocket-client`

### Bước 2: Cấu Hình MCP Server

Tạo hoặc cập nhật file `mcp_config.json` trong thư mục cấu hình Antigravity:

**Vị trí file cấu hình:**
- Windows: `C:\Users\<USERNAME>\.gemini\antigravity\mcp_config.json`
- macOS/Linux: `~/.gemini/antigravity/mcp_config.json`

**Nội dung file:**
```json
{
    "mcpServers": {
        "notebooklm": {
            "command": "<ĐƯỜNG_DẪN_PYTHON>",
            "args": ["-m", "notebooklm_mcp_hybrid.server"],
            "cwd": "<ĐƯỜNG_DẪN_ĐẾN_THƯ_MỤC_NÀY>/src"
        }
    }
}
```

**Lưu ý cho AI Agent:**
- Thay `<ĐƯỜNG_DẪN_PYTHON>` bằng kết quả của lệnh: `python -c "import sys; print(sys.executable)"`
- Thay `<ĐƯỜNG_DẪN_ĐẾN_THƯ_MỤC_NÀY>` bằng đường dẫn tuyệt đối đến thư mục chứa file này
- Sử dụng forward slashes `/` thay vì backslashes `\` trong đường dẫn

### Bước 3: Xác Thực NotebookLM

Sau khi cấu hình xong, chạy lệnh xác thực:

```powershell
notebooklm-mcp-auth
```

**Điều gì sẽ xảy ra:**
1. Trình duyệt Chrome sẽ mở lên
2. Người dùng đăng nhập vào tài khoản Google
3. Truy cập notebooklm.google.com
4. Script tự động lấy cookies và lưu lại

**Xử lý lỗi:**
- Nếu Chrome không mở: Đảm bảo Chrome đã được cài đặt
- Nếu lỗi "command not found": Chạy `python -m notebooklm_mcp_hybrid.auth_cli`

### Bước 4: Reload Antigravity

Yêu cầu người dùng:
1. Nhấn `Ctrl+Shift+P`
2. Gõ "Reload Window"
3. Chọn "Developer: Reload Window"

### Bước 5: Kiểm Tra Kết Nối

Sau khi reload, thử gọi tool:

```
mcp_notebooklm_notebook_list
```

**Kết quả mong đợi:** Danh sách notebooks của người dùng

### Bước 6 (Tùy chọn): Multi-Account Setup

Nếu muốn sử dụng nhiều tài khoản Google:

```powershell
# Tạo profile cho tài khoản thứ 2
notebooklm-mcp-auth --profile work

# Đăng nhập vào tài khoản khác trong Chrome popup
```

**Cấu hình thêm server trong `mcp_config.json`:**
```json
{
  "mcpServers": {
    "notebooklm": { ... },
    "notebooklmWork": {
      "command": "<PYTHON_PATH>",
      "args": ["-m", "notebooklm_mcp_hybrid.server"],
      "cwd": "<PATH>/src",
      "env": {
        "NOTEBOOKLM_AUTH_DIR": "~/.notebooklm-mcp-work"
      }
    }
  }
}
```

**Xem mẫu cấu hình đầy đủ:** [mcp_config.sample.json](mcp_config.sample.json)

> ⚠️ **Giới hạn:** Antigravity chỉ hỗ trợ tối đa 2 MCP servers hoạt động đồng thời

### 🔧 Troubleshooting

Xem file [TROUBLESHOOTING.md](TROUBLESHOOTING.md) để:
- Giải quyết lỗi xác thực
- Cấu hình multi-account
- Debug các vấn đề phổ biến

---

## 📖 Hướng Dẫn Sử Dụng Cho Người Dùng

### Các Lệnh Cơ Bản

| Yêu cầu | Tool sử dụng |
|---------|--------------|
| "Liệt kê notebooks của tôi" | `notebook_list` |
| "Tạo notebook mới về AI" | `notebook_create` |
| "Thêm URL này vào notebook" | `notebook_add_url` |
| "Hỏi notebook về chủ đề X" | `notebook_query` |
| "Nghiên cứu sâu về Y" | `research_start` |
| "Tạo podcast từ notebook" | `audio_overview_create` |

### Quy Trình Nghiên Cứu Sâu

1. **Bắt đầu nghiên cứu:**
   ```
   research_start(query="chủ đề cần nghiên cứu", mode="deep")
   ```

2. **Kiểm tra tiến độ:**
   ```
   research_status(notebook_id="...", max_wait=300)
   ```

3. **Import nguồn tìm được:**
   ```
   research_import(notebook_id="...", task_id="...")
   ```

### Quy Trình Tạo Nội Dung Studio

1. **Tạo nội dung (cần xác nhận):**
   ```
   audio_overview_create(notebook_id="...", confirm=True)
   ```

2. **Kiểm tra trạng thái:**
   ```
   studio_status(notebook_id="...")
   ```

---

## 🔧 Xử Lý Sự Cố

### Lỗi "Authentication failed"

**Nguyên nhân:** Token xác thực hết hạn

**Giải pháp:**
```powershell
notebooklm-mcp-auth
```

### Lỗi "Module not found"

**Nguyên nhân:** Package chưa được cài đặt đúng cách

**Giải pháp:**
```powershell
cd "<ĐƯỜNG_DẪN_PROJECT>"
pip install -e .
```

### MCP Server không xuất hiện trong Antigravity

**Nguyên nhân:** Config chưa được load

**Giải pháp:**
1. Kiểm tra file `mcp_config.json` đúng vị trí
2. Reload Window (`Ctrl+Shift+P` → "Reload Window")

### Lỗi Unicode/Encoding trên Windows

**Nguyên nhân:** Console không hỗ trợ UTF-8

**Giải pháp:** Không ảnh hưởng đến hoạt động của MCP server

---

## 📁 Cấu Trúc Thư Mục

```
notebooklm-mcp-hybrid/
├── README.md              # File này
├── pyproject.toml         # Cấu hình package
└── src/
    └── notebooklm_mcp_hybrid/
        ├── __init__.py
        ├── server.py      # MCP Server chính (Vietnamese)
        ├── api_client.py  # NotebookLM API client
        ├── auth.py        # Xác thực
        ├── auth_cli.py    # CLI xác thực
        └── constants.py   # Hằng số
```

---

## 🔗 Tham Khảo

- [NotebookLM](https://notebooklm.google.com) - Sản phẩm của Google
- [MCP Protocol](https://modelcontextprotocol.io) - Model Context Protocol
- [jacob-bd/notebooklm-mcp](https://github.com/jacob-bd/notebooklm-mcp) - Project gốc (English)

---

## 📝 Ghi Chú Cho AI Agent

### Checklist Cài Đặt Hoàn Chỉnh

- [ ] Python >= 3.10 đã cài đặt
- [ ] Package đã được install (`pip install -e .`)
- [ ] File `mcp_config.json` đã được tạo đúng vị trí
- [ ] Đường dẫn Python và project trong config là chính xác
- [ ] Đã chạy `notebooklm-mcp-auth` để xác thực
- [ ] Đã Reload Window
- [ ] Tool `notebook_list` hoạt động

### Template Thông Báo Cho Người Dùng

**Khi bắt đầu:**
> Tôi sẽ cài đặt NotebookLM MCP Server cho bạn. Quá trình này cần bạn:
> 1. Đăng nhập Google khi trình duyệt mở lên
> 2. Reload cửa sổ khi tôi yêu cầu

**Khi cần xác thực:**
> Trình duyệt Chrome sẽ mở lên. Vui lòng đăng nhập vào tài khoản Google của bạn và truy cập NotebookLM. Tôi sẽ tự động lấy thông tin xác thực.

**Khi hoàn thành:**
> Cài đặt hoàn tất! Bạn có thể yêu cầu tôi các việc như:
> - "Liệt kê notebooks của tôi"
> - "Tạo podcast về chủ đề X"
> - "Nghiên cứu sâu về Y"

---

*Bản quyền: Fork từ [jacob-bd/notebooklm-mcp](https://github.com/jacob-bd/notebooklm-mcp) với Vietnamese translations.*
